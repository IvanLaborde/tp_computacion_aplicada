#!/bin/bash

# Validar argumentos
if [[ "$1" == "-help" || $# -ne 2 ]]; then
    echo "Uso: $0 <directorio_origen> <directorio_destino>"
    echo "Ejemplo: $0 /var/log /backup_dir"
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz

# Validar si origen y destino existen y están montados
if [ ! -d "$ORIGEN" ]; then
    echo "El directorio origen '$ORIGEN' no está montado o no existe."
    exit 1
fi

if ! mountpoint -q "$DESTINO"; then
    echo "El directorio destino '$DESTINO' no está montado o no existe."
    exit 1
fi

# Ejecutar backup
tar -czf "$DESTINO/$NOMBRE" "$ORIGEN" 2>/dev/null

if [[ $? -eq 0 ]]; then
    echo "Backup exitoso: $DESTINO/$NOMBRE"
else
    echo "Hubo un error durante el backup."
fi
