<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$port = "3306";
$username = "1cars";
$password = "NCCI7O1D";
$dbname = "ingenieria";

echo "Intentando conectar como $username@$servername con clave $password<br>";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Error de conexion: " . $conn->connect_error);
}

$sql = "SELECT 
    alumnos.legajo AS legajo,
    alumnos.apellido AS apellido,
    alumnos.nombres AS nombre,
    modulos.nom_modulo AS materia,
    notas.nota AS nota
FROM alumnos, modulos, notas
WHERE alumnos.legajo = notas.legajo";

$result = $conn->query($sql);
if (!$result) {
    die("Error en la consulta: " . $conn->error);
}

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "Legajo: " . $row["legajo"] . " - Nombre: " . $row["nombre"] . " - Apellido: " . $row["apellido"] . 
             " - Materia: " . $row["materia"] . " - Nota: " . $row["nota"] . "<br>";
    }
} else {
    echo "No hay resultados.";
}

$conn->close();
?>
